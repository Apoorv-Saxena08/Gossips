package com.mycompany.gossips

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
