import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAfc2V2xJWIa9RUmj0PXfITlK5gV8tWKKM",
            authDomain: "gossips-d9154.firebaseapp.com",
            projectId: "gossips-d9154",
            storageBucket: "gossips-d9154.firebasestorage.app",
            messagingSenderId: "826303546986",
            appId: "1:826303546986:web:83a8f07120d2b36235ac13"));
  } else {
    await Firebase.initializeApp();
  }
}
